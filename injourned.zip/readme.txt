injourned.exe
Made by ConduciveGDI
New stupid malware
It contains jumpscare!