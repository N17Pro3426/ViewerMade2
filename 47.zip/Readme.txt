47.exe
GDI, bytebeats and destructive payloads made in C#
Kernel in C and ASM
Made by MalwareLab150 (a.k.a. MalwareLab2.0)
Credits to OneFive_Malware for reporting the kernel text bug
Credits to Calibrato for some bytebeats
It's a private GDI malware inspired by the famous DMT (a.k.a. N,N-Dimethyltryptamine) an intense psychedelic present in the pineal gland.
Try on Windows 7 for the easter egg.
Now the kernel works :)