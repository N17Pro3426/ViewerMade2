You'll need .NET Framework 3.5 or higher for this to work.
Also, epilepsy warning!
Made by ChrisRM_380
Also, this thing is heavily inspired by InfiniteBlue.