1-majoor.exe
A malware with 20 GDI effects (skidded) and bytebeats lasting 6 minutes
Made by propamza
Stolen name from Ursa Major?