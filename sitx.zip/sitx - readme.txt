 .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------. 
| .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |
| |    _______   | || |     _____    | || |  _________   | || |  ____  ____  | || |              | || |  _________   | || |  ____  ____  | || |  _________   | |
| |   /  ___  |  | || |    |_   _|   | || | |  _   _  |  | || | |_  _||_  _| | || |              | || | |_   ___  |  | || | |_  _||_  _| | || | |_   ___  |  | |
| |  |  (__ \_|  | || |      | |     | || | |_/ | | \_|  | || |   \ \  / /   | || |              | || |   | |_  \_|  | || |   \ \  / /   | || |   | |_  \_|  | |
| |   '.___`-.   | || |      | |     | || |     | |      | || |    > `' <    | || |              | || |   |  _|  _   | || |    > `' <    | || |   |  _|  _   | |
| |  |`\____) |  | || |     _| |_    | || |    _| |_     | || |  _/ /'`\ \_  | || |      _       | || |  _| |___/ |  | || |  _/ /'`\ \_  | || |  _| |___/ |  | |
| |  |_______.'  | || |    |_____|   | || |   |_____|    | || | |____||____| | || |     (_)      | || | |_________|  | || | |____||____| | || | |_________|  | |
| |              | || |              | || |              | || |              | || |              | || |              | || |              | || |              | |
| '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |
 '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------' 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Authors: UltraDasher965 & Number333
Made in: C++
Compatibility: Windows Vista-11
Creation time: 3 days
Number of payloads: 14
Damage rate: Destructive
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
It is recommended to run the safety version if you wish to test this on your main PC, except if you're confident enough and you want to run the destructive
version. The creators are not responsible for any damages caused to your PC or VM! If you execute it, your Master Boot Record would be overwritten, and you
would have to reinstall your operating system. pankoza, N17Pro3426, Abraham34535, camellia-y7x and NindowsCahel132 are NOT allowed to steal anything from
sitx.exe, even if camellia-y7x left the internet.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Credits to VenraTech/Executioner for 1 payload
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Hello Crypto NWO, N17Pro3426, Deca Quitin, Abimega7890, VenraTech, Wooshydudebro, CYBER SOLDIER, Gabolate, CiberBoy and you, the person reading this!
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -






























































"Friends with VenraTech? Unfriend them immediately" - WinAero2008