Delta.exe by VietNamLover.
Don't run this malware on your real PC.
Differences compared to wgwcpdpgbf.exe by pankoza:
This malware has more 4 payloads, changed texts and it will not disable Task Manager.