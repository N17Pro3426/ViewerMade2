Dealt1.5.exe by VietNamLover.
Don't run this malware on your real PC!
This GDI malware has 14 payloads.
This is a remake of wgwcpdpgbf.exe by pankoza and Delta.exe by VietNamLover (me).
Update of Dealt.exe: added more 4 payloads and bytebeats.
Enjoy! =)