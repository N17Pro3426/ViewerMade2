My new virus after a long break.
Definitely too long! (doubtful)
With source code.
Don't worry about licenses; think of it as a royalty-free version of a copyrighted song.