pentacyanocyclopentadiene by pankoza and UltraDasher965
This is our first collab malware and pankoza's second collab after xml.exe collab with fr4ctalz back in 2023
Credits to Malsteve527 for the Hue function
Credits to EthernalVortex for PRGBQUAD
Credits to SapphireTech for the icons payload in the 3rd payload

This is a GDI malware
The creators are NOT responsible for ANY damage.
Do NOT run it if you have epilepsy or heart issues.
This is very dangerous for the non-safety version
The non-safety version will overwrite the MBR and will make your PC unbootable.

Creation date: February 14, 2026