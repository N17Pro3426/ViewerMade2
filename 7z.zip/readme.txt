Tested only on Windows 10
This is a harmless malware called 7z.exe
Made by anotheraccount
It has 12 payloads (longer than my usual malwares)
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...