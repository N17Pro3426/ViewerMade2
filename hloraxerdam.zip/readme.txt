Malware name: hloraxerdam
Malware type: WINGDI32, WINTROJAN and Safety WIN32
Arch: x64/x86, arm (any CPU)
This is a safety malware!
It contains flashing lights and fast color changing.
Don't run it if you have epilepsy and slow processor (GPU), cuz it can cause fatal errors or damage.
The creator (DeX2PM) is NOT responsible for ANY damage to your PC!
Thanks for running and reading...