Tested only on Windows 10
This is a harmless malware called Glazed Terracotta.exe
Made by anotheraccount
The name and icon was inspired by XUGE.
It's also apparently the weakest block in Minecraft.
It has a 50/50 chance of running after the warnings!
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...