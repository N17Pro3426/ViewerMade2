Phenyrane.exe by VietNamLover.
This GDI malware has 9 payloads (10 if you count the outro).
This is a safe GDI malware, so you can run it on your real PC.
Differences compared to Phenylsilatrane.exe by pankoza:
Changed texts and bytebeats.