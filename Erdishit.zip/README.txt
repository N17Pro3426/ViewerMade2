-------------------------------------------------------
| ______         _ _     _     _ _                    |
||  ____|       | (_)   | |   (_) |                   |
|| |__   _ __ __| |_ ___| |__  _| |_   _____  _____   |
||  __| | '__/ _` | / __| '_ \| | __| / _ \ \/ / _ \  |
|| |____| | | (_| | \__ \ | | | | |_ |  __/>  <  __/  |
||______|_|  \__,_|_|___/_| |_|_|\__(_)___/_/\_\___|  |
|                                                     |
-------------------------------------------------------
My first ever GDI malware!
7 days in making it to finish this virus!
Made in C++ by TrophixYT
Bytebeat helped by DJ TLK Original & N4RMAL

|--------------------------------------------------------------|
| Socials here!						       |
| DJ TLK Original = https://www.youtube.com/@djtlkoriginalcrlh |
| TrophixYT = https://www.youtube.com/@TrophixYT	       |
| N4RMAL = https://www.youtube.com/@N4RMALisreal	       |
|--------------------------------------------------------------|

----------------------------WARNING-----------------------------
Don't run the destructive version on a real hardware unless you
know what you're doing. Make sure to create a snapshot to recover
your files, if you want to run this! I also recommend you to run
this ONLY on a virtual machine. This malware wasn't made for
malicious purposes, run it at your own risk! Run the safety
version, if you don't want your PC to die.

---------------------ASCII art settings fix---------------------
To see the ASCII art more better, make sure your notepad size is
100%. You can check this by the bottom right corner beside where
it shows the line and col. Change the size by using your mouse
scroll while holding Ctrl.