EternalBlack.exe by MohammedHadeedNoori
You have to run the non-safety version as administrator or it won't overwrite the MBR.
Credits to ArTicZera and wipet for the HSL function.
Credits to GetMBR for the Hue function.
This malware contains flashing lights, NOT for epilepsy.
If you want to run it on Windows XP, you have to install One-Core API.