Tera+RGB.exe
My new malware
This malware is very dangerous for non-safety version.
This trojan can harm your computer and wipe the C: drive and MBR.
Use it ONLY on a Virtual Machine.
It works ONLY on Windows XP.
Run it as administrator on Windows 7.
Credits to N17Pro3426, ChrisRM_380 and Cactos for verifying my malware.
Please note that the creator (KozaResponding2) is NOT responsible for ANY damages.
Programming language: C#
This is a modification of Tera Bonus (NOT skidded)
Waiting 5 seconds in red and blue gives the rainbow MBR.