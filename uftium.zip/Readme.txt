uftium.exe by VietNamLover.
This GDI malware has 20 payloads.
This is a safe GDI malware, so you can run it on your real PC.
Differences compared to xjmjivqdmpn.exe by pankoza:
This malware has new bytebeats and changed texts.