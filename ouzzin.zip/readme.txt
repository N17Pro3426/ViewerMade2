ouzzin.exe
The best Monoxide remake
Works on Windows Vista-11
If you want to run it on Windows XP, you'll need to install OneCore-API
Good luck!