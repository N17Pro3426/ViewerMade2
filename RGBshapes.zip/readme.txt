RGBshapes.exe
Made by lipkoza
Press Esc to close it
Bye!