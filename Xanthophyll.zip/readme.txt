Xanthophyll.exe
-------------
What is Xanthophyll?
Xanthophyll (Xanthophylle in german) is a yellow pigment derived from carotenoids. Although its molecular structure is based
on carotene, unlike carotene, it has a structure in which some of the hydrogen atoms are replaced by hydroxyl groups or pairs
of hydrogen atoms bonded to the same carbon atom are replaced by oxo groups (by Wikipedia).
Molecular formula: C40H56O2
-------------
Development language: C++ and Assembly
Operating environment: 32-bit and 64-bit
-------------
WARNING!
You must run this ONLY on a virtual environment, because it will destroy the MBR. Run at your own risk.
-------------
Message from the author:
You may not be able to view the MBR payload. It worked fine in QEMU, so why not here? So, if you can see it, you might be lucky
or you might not.
-------------
Have fun!!!