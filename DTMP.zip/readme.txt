Tested only on Windows 10
This is a harmless malware called DTMP.exe
Remember, don't touch my pizza!
Made by anotheraccount
When you run this, it will open a YouTube link to nyanwolf's music video!
Epilepsy warning!
Also, never run this malware if you hate the song, and don't harrass the creator!
Made in Dev-C++
Credits to zombycare for the song, and everyone else.
For skidders: please credit to me if you use the source code!

idk what else to put here...