﻿ ██████╗███████╗███████╗██╗██╗   ██╗███╗   ███╗   ███████╗██╗  ██╗███████╗
██╔════╝██╔════╝██╔════╝██║██║   ██║████╗ ████║   ██╔════╝╚██╗██╔╝██╔════╝
██║     █████╗  ███████╗██║██║   ██║██╔████╔██║   █████╗   ╚███╔╝ █████╗  
██║     ██╔══╝  ╚════██║██║██║   ██║██║╚██╔╝██║   ██╔══╝   ██╔██╗ ██╔══╝  
╚██████╗███████╗███████║██║╚██████╔╝██║ ╚═╝ ██║██╗███████╗██╔╝ ██╗███████╗
 ╚═════╝╚══════╝╚══════╝╚═╝ ╚═════╝ ╚═╝     ╚═╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
The "You killed niko" trojan
=============================================================================================
Hello! This is my first GDI malware ever called cesium.exe.
This malware took about a month to be made, and was written in C#.

This is the version 1.2 of it. Key changes:
1. bug fixes
2. optimizations
3. ~60% of code rewritten
4. small tweaks

This malware was private, but now it's public and open source on Silverjetes's GitHub!
This malware uses undocumented features such as NtRaiseHardError for triggering a BSoD

In order to run it, install .NET Framework 4.0. Download link:
https://download.microsoft.com/download/9/5/a/95a9616b-7a37-4af6-bc36-d6ea96c8daae/dotNetFx40_Full_x86_x64.exe

Run on Windows XP/7 ONLY with Basic theme, because otherwise the GDI would be VERY slow.
=============================================================================================
Credits to ClutterTech (CYBER SOLDIER), CiberBoy, MalwareLab150 (Mattia) & holymacaroniwhybruh.

HUGE thanks to CiberBoy for making the first payload, optimizing the error icon payload, and helping me
with window distortion payloads!
Safe version made by SapphireTech

Thank you all for the help with my trojan! :D
=============================================================================================
by silverjetes <3
02/25