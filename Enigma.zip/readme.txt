Enigma.exe by anotheraccount
WARNING! This malware has very annoying and possibly destructive payloads!
The safety version has only the GDI.
What it can do?:
1. Open random programs
2. Move and resize windows
3. Change window titles
4. Move the cursor (but in a unique way)
5. Make the cursor left and right click
6. Flash windows (with the FlashWindow function)
7. Send random keystrokes (it was written by ChatGPT, so it may not work)
I'm NOT responsible for ANY damages to your computer!
Fake BSOD was inspired by Sulfoxide
Credits to malsteve527 for his Hue shift function
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!