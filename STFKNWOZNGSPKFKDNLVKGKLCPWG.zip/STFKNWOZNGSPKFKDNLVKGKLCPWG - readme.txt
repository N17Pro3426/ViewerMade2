STFKNWOZNGSPKFKDNLVKGKLCPWG.exe by TELEPATHII
This malware was made in 2 hours (I already prepared some shaders)
This program is dangerous, it's recommended to run the safe version in your real PC.
Credits to UltraDasher965 for the icon and the last payload, but I modified it (I had permission)

Hi N17Pro3426, UltraDasher965, Deca Quitin & Crypto NWO!