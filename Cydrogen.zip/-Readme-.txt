 _______  __   __  ______   ______    _______  _______  _______  __    _ 
|       ||  | |  ||      | |    _ |  |       ||       ||       ||  |  | |
|       ||  |_|  ||  _    ||   | ||  |   _   ||    ___||    ___||   |_| |
|       ||       || | |   ||   |_||_ |  | |  ||   | __ |   |___ |       |
|      _||_     _|| |_|   ||    __  ||  |_|  ||   ||  ||    ___||  _    |
|     |_   |   |  |       ||   |  | ||       ||   |_| ||   |___ | | |   |
|_______|  |___|  |______| |___|  |_||_______||_______||_______||_|  |__|

Tipo/Type: GDI-Trojan.Win32.Cydrogen
Contato em/Contact on Discord: eu_edu212

PT-BR: Este é um malware que fará com que o seu PC inicie com mais frequência.
O criador NÃO é responsável por nada.

EN-US: This is a malware that will make your PC start more frequently. The
creator is NOT responsible for anything.