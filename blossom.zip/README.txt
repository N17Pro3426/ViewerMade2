blossom.exe
a.k.a. flowerdows (Trojan.Win32.Generic)
------------------------------------------------------------------------------------------
This is a malware made by VenraTech.
It's my submission for the WinMalware YouTube channel.
------------------------------------------------------------------------------------------
Information about blossom.exe:
Malware type: Trojan.Win32.Generic
Destructive?: No
Coded in: C++
------------------------------------------------------------------------------------------
Credits to RaduMinecraft for the cube
Credits to BBVM for the inspiration: https://youtu.be/ZzDfhL9xGjE?si=upoQv46jDpku_eUJ
Credits to the other people who I forgot about.
------------------------------------------------------------------------------------------

























































"this is the end, friend"