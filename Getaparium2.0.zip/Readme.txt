Getaparium2.0.exe by VietNamLover.
Don't run this malware on your real PC!
This GDI malware has 18 payloads.
Update 3 of Getaparium.exe:
Changed all texts and bytebeats.