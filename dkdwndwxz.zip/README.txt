 ____ ____ ____ ____ ____ ____ ____ ____ ____ 
||d |||k |||d |||w |||n |||d |||w |||x |||z ||
||__|||__|||__|||__|||__|||__|||__|||__|||__||
|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|

dkdwndxz.exe malware
Comes included with safety and destructive
Recommended to run on a virtual machine
Use 800x600, it can run on Windows 7-11