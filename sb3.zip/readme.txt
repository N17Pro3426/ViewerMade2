░██████╗██████╗░██████╗░
██╔════╝██╔══██╗╚════██╗
╚█████╗░██████╦╝░█████╔╝
░╚═══██╗██╔══██╗░╚═══██╗
██████╔╝██████╦╝██████╔╝
╚═════╝░╚═════╝░╚═════╝░
I dunno why I have an entire readme file for this malware, but here are some malware I was inspired by!
Tera Bonus: The PlgBlt in 12th payload and the Bezier
Some of N17Pro3426's malwares: The bouncing ball
Holzer: The modified circle thing
jfif, tif and Holmium: Sharpening effect (not skidded from Holmium, its my own version)
ColorCs: The 9th payload
jpeg and jpg: The 5th payload and the embedded WAV files
----------------------------------------------------------------------------------------------------------------------------------
Please take note that it's NOT skidded, but some effects are similar to some malwares!