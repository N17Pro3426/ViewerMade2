Monoxide by wipet, but modified by ChrisRM_380.
I removed all the destructive features of Monoxide, so don't expect data loss,
but you might lose unsaved data by uncontrollably high level flashing lights & loud noises,
which can cause seizures.