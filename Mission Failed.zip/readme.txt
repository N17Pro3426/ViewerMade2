Tested only on Windows 10
This is a harmless malware called Mission Failed.exe
Made by anotheraccount
Epilepsy warning!
Made in Dev-C++
Also, I figured out how to make the bytebeats work!
For skidders: please credit to me if you use the source code!

idk what else to put here...
Also, I put the Portal 2 icon, because yes.