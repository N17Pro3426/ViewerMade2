Getaparium1.5.exe by VietNamLover.
This GDI malware has 18 payloads.
This is a safe GDI malware, so you can run it on your real PC.
Update of Getaparium.exe:
Changed more bytebeats.