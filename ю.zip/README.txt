                                                               /$$                
                                                              | $$                
 /$$   /$$          /$$$$$$   /$$$$$$  /$$$$$$/$$$$   /$$$$$$ | $$   /$$  /$$$$$$ 
| $$  | $$ /$$$$$$ /$$__  $$ /$$__  $$| $$_  $$_  $$ |____  $$| $$  /$$/ /$$__  $$
| $$  | $$|______/| $$  \__/| $$$$$$$$| $$ \ $$ \ $$  /$$$$$$$| $$$$$$/ | $$$$$$$$
| $$  | $$        | $$      | $$_____/| $$ | $$ | $$ /$$__  $$| $$_  $$ | $$_____/
|  $$$$$$$        | $$      |  $$$$$$$| $$ | $$ | $$|  $$$$$$$| $$ \  $$|  $$$$$$$
 \____  $$        |__/       \_______/|__/ |__/ |__/ \_______/|__/  \__/ \_______/
 /$$  | $$                                                                        
|  $$$$$$/                                                                        
 \______/                                                                         
----------------------------------------------------------------------------------------
Hello there!
What you have in this folder is ю, a remake of the popular ÿ.exe malware by Leurak.
This remake features similar effects on screen using GDI.
It's fully written in the C# programming language, targeting .NET Framework 4, link below.
----------------------------------------------------------------------------------------
This malware is made ONLY for Windows XP, x64 is faster but x86 gets it done too.
Running it on other OSes would cause stability issues, slow payloads and non-working payloads.
That is why we made it only available on Windows XP.
This malware can:
 - Set its own process as critical so it can't be killed
 - Play pre-recorded audio and beeps
 - Corrupt all files with symbols
 - Replace the master boot record with random bytes.
 - Crash processes by writing random data to the processes.
 - Fill the memory slowly.
 - Block all user input
 - Move the mouse and randomly click and do keyboard inputs
 - Spawn message boxes with gibberish content.
 - Replace text strings and titlebars with the malware's name.
 - Open random files in %windir%
 - Draw GDI effects on the screen
----------------------------------------------------------------------------------------
DISCLAIMER!
The creators (Silverjetes and CiberBoy) won't make responsible for data loss or
any damage caused by the misuse of this software! You are responsible for your actions.
----------------------------------------------------------------------------------------
LICENSE
This malware is open source. Anybody can check and modify the code as their liking, but
if they use part of our code, they should make their project open source as well!
----------------------------------------------------------------------------------------
Made by CiberBoy and Silverjetes.
CiberBoy: https://www.youtube.com/@ciberboyYT
Silverjetes: https://www.youtube.com/@silverjetes
.NET Framework 4: https://www.microsoft.com/en-us/download/details.aspx?id=17718