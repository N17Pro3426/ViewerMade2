Llanitopia.exe
Made by ConduciveGDI
It's Babi Guling.exe, but with more faces.