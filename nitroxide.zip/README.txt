 _   _ _ _                 _     _      
| \ | (_) |               (_)   | |     
|  \| |_| |_ _ __ _____  ___  __| | ___ 
| . ` | | __| '__/ _ \ \/ / |/ _` |/ _ \
| |\  | | |_| | | (_) >  <| | (_| |  __/
|_| \_|_|\__|_|  \___/_/\_\_|\__,_|\___|

-------------------------------------------------------------------------------------
Hello there! What you have is nitroxide, a GDI malware made by CiberBoy. It's coded
in C# and the MBR in ASM. This malware is like a trip, and it has original GDI
effects along with some bytebeats. This malware can only run on Windows XP, 64-bit
is recommended, but it also works on 32-bit. If you run on other OS, it will flood
your screen with popups and shakes for 5 seconds then destroy PC. You'll need .NET
Framework 4.0. This malware took me 5 days to make like coding 2 hours a day.
-------------------------------------------------------------------------------------
WARNING!
You mustn't share this malware with anybody or give ANY download link! Doing that is
violating this malware terms! Also, you mustn't do ANY video without CiberBoy's
permission!
-------------------------------------------------------------------------------------
BE CAREFUL!
This malware is destructive and should only be ran on VM! CiberBoy won't make
responsible of damages caused by the incorrect use of this malware. It can destroy
the MBR, the registry, system32 and encrypt files.
-------------------------------------------------------------------------------------
Credits and details:
 - All GDI is coded by CiberBoy in C#
 - MBR is made by MalwareLab in ASM and it's interactive
 - Bytebeats are also made by CiberBoy
 - Text payload uses part of the code of TrojanXD
-------------------------------------------------------------------------------------
This will probably be my last GDI malware. Why? Well, I think GDI became boring at
all, everything is just the same and skids have taken everything. From now on, I'll
still do malwares, but different type. Of course, they will have GDI, but NOT only
that.
-------------------------------------------------------------------------------------
Have a good day!
CiberBoy :)