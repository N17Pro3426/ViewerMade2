                                                                                                                                                                                    
            ,dPYb,                            ,dPYb,                        8I                                                                                                      
            IP'`Yb                            IP'`Yb                        8I                                                                                                      
            I8  8I                            I8  8I                        8I                                                                                        gg            
            I8  8'                            I8  8'                        8I                                                                                        ""            
  ,gggggg,  I8 dPgg,    ,gggggg,    ,ggggg,   I8 dPgg,     ,ggggg,    ,gggg,8I    ,ggggg,   gg,gggg,     ,gggggg,    ,ggggg,   gg,gggg,      ,gggg,gg   ,ggg,,ggg,    gg     ,gggg, 
  dP""""8I  I8dP" "8I   dP""""8I   dP"  "Y8gggI8dP" "8I   dP"  "Y8gggdP"  "Y8I   dP"  "Y8gggI8P"  "Yb    dP""""8I   dP"  "Y8gggI8P"  "Yb    dP"  "Y8I  ,8" "8P" "8,   88    dP"  "Yb
 ,8'    8I  I8P    I8  ,8'    8I  i8'    ,8I  I8P    I8  i8'    ,8I i8'    ,8I  i8'    ,8I  I8'    ,8i  ,8'    8I  i8'    ,8I  I8'    ,8i  i8'    ,8I  I8   8I   8I   88   i8'      
,dP     Y8,,d8     I8,,dP     Y8,,d8,   ,d8' ,d8     I8,,d8,   ,d8',d8,   ,d8b,,d8,   ,d8' ,I8 _  ,d8' ,dP     Y8,,d8,   ,d8' ,I8 _  ,d8' ,d8,   ,d8b,,dP   8I   Yb,_,88,_,d8,_    _
8P      `Y888P     `Y88P      `Y8P"Y8888P"   88P     `Y8P"Y8888P"  P"Y8888P"`Y8P"Y8888P"   PI8 YY88888P8P      `Y8P"Y8888P"   PI8 YY88888PP"Y8888P"`Y88P'   8I   `Y88P""Y8P""Y8888PP
                                                                                            I8                                 I8                                                   
                                                                                            I8                                 I8                                                   
                                                                                            I8                                 I8                                                   
                                                                                            I8                                 I8                                                   
                                                                                            I8                                 I8                                                   
                                                                                            I8                                 I8                                                   

Lazy to type a readme, but just don't run this on a real PC!
Use 800x600 for the fast GDI effects.