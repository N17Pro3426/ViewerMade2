Structium.exe by VietNamLover.
This GDI malware has 20 payloads.
This is a safe GDI malware, so you can run it on your real PC.
Differences compared to isopropoxide.exe by pankoza:
This malware has been modified with new bytebeats.
From the 10th to the last payload, you can see the "isopropoxide.exe" text, cuz I forgot to change it.
Well, I'll update this malware soon.