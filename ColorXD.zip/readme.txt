ColorXD.exe by MalvareKing. 
It's a colorful GDI malware. 
Made in C++.
It's a dangerous GDI malware with overwriting the MBR.
