M   M EEEEE M   M  OOO  X   X III DDDD  EEEEE RRRR
MM MM E     MM MM O   O  X X   I  D   D E     R   R
M M M EEEE  M M M O   O   X    I  D   D EEEE  RRRR
M   M E     M   M O   O  X X   I  D   D E     R R
M   M EEEEE M   M  OOO  X   X III DDDD  EEEEE R  RR

MemoxideR.exe
Made by MalvareKing
Original by WilliamPatch692 and TBSVEHD584
It corrupts the MBR and disables Task Manager and Registry Editor
Have happy run!
:D