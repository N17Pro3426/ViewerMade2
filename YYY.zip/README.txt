 __      __  __      __  __      __  ________  __    __  ________
|  \    /  \|  \    /  \|  \    /  \|        \|  \  |  \|        \
 \$$\  /  $$ \$$\  /  $$ \$$\  /  $$| $$$$$$$$| $$  | $$| $$$$$$$$
  \$$\/  $$   \$$\/  $$   \$$\/  $$ | $$__     \$$\/  $$| $$__
   \$$  $$     \$$  $$     \$$  $$  | $$  \     >$$  $$ | $$  \
    \$$$$       \$$$$       \$$$$   | $$$$$    /  $$$$\ | $$$$$
    | $$        | $$        | $$ __ | $$_____ |  $$ \$$\| $$_____ 
    | $$        | $$        | $$|  \| $$     \| $$  | $$| $$     \
     \$$         \$$         \$$ \$$ \$$$$$$$$ \$$   \$$ \$$$$$$$$
 -------------------------------------------------------------------------
This malware is very dangerous for non-safety.
It has 4 GDI payloads and BSOD.
Don't try to close the program, it will not work with this version.
It can wipe the C: drive and please note that this malware is dangerous!
I'm NOT responsible for ANY damage.
Credits to Abrahamtestgdiviruses and N17Pro3426
Made in: C#, .NET Framework 3.5
Fun fact: You can fix it if you want.
Second fact: Also Windows XP makes the GDI better.