WailenPolyer.B.exe
My new malware
Credits to Trisodium Phosphate, ChrisRM_380 and N17Pro3426