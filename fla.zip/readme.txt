███████╗██╗░░░░░░█████╗░░░░███████╗██╗░░██╗███████╗
██╔════╝██║░░░░░██╔══██╗░░░██╔════╝╚██╗██╔╝██╔════╝
█████╗░░██║░░░░░███████║░░░█████╗░░░╚███╔╝░█████╗░░
██╔══╝░░██║░░░░░██╔══██║░░░██╔══╝░░░██╔██╗░██╔══╝░░
██║░░░░░███████╗██║░░██║██╗███████╗██╔╝╚██╗███████╗
╚═╝░░░░░╚══════╝╚═╝░░╚═╝╚═╝╚══════╝╚═╝░░╚═╝╚══════╝

Malware name: fla.exe
Made in: Dev-C++ 5.11
Creator: HadeedDoesStuff
Creation date: 15.06.2025

This malware is harmless, so it will NOT harm your computer. You can test it on your real computer if you'd like, but I recommended to test it on a virtual machine.