Nodelug.exe
I coded everything based on 1920×1080 resolution
So, if your resolution is not 1920×1080, it will not work properly
This malware works correctly on Windows XP
Creator: Datriunus#6323