Tested only on Windows 10
This is a harmless malware called Dystopia.exe
Made by anotheraccount
Epilepsy warning!
Made in Dev-C++

idk what else to put here...