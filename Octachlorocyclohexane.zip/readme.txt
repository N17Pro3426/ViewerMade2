 OOOOO   CCCCC TTTTT AAAAA   CCCCC  H   H L     OOOOO  RRRRR   OOOOO   CCCCC Y   Y CCCCC  L     OOOOO  H   H EEEEE X   X  AAAAA  N   N EEEEE
O     O C     C  T  A     A C     C H   H L    O     O R    R O     O C     C Y Y C     C L    O     O H   H E      X X  A     A NN  N E
O     O C        T  AAAAAAA C       HHHHH L    O     O RRRRR  O     O C        Y  C       L    O     O HHHHH EEEE    X   AAAAAAA N N N EEEE
O     O C     C  T  A     A C     C H   H L    O     O R   R  O     O C     C  Y  C     C L    O     O H   H E      X X  A     A N  NN E
 OOOOO   CCCCC   T  A     A  CCCCC  H   H LLLLL OOOOO  R    R  OOOOO   CCCCC   Y   CCCCC  LLLLL OOOOO  H   H EEEEE X   X A     A N   N EEEEE

Made by lipkoza
My new malware
Bye!