Tested only on Windows 10
This is a harmless malware called Untrihexium.exe
Made by anotheraccount
It has 10 payloads (11 if you count the outro)
Credits to malsteve527 for his Hue shift function
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...