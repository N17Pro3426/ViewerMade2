 /$$$$$$$                        /$$                           /$$     /$$                                                          
| $$__  $$                      | $$                          | $$    |__/                                                          
| $$  \ $$ /$$   /$$  /$$$$$$$ /$$$$$$    /$$$$$$   /$$$$$$  /$$$$$$   /$$ /$$   /$$ /$$$$$$/$$$$       /$$$$$$  /$$   /$$  /$$$$$$ 
| $$  | $$| $$  | $$ /$$_____/|_  $$_/   /$$__  $$ /$$__  $$|_  $$_/  | $$| $$  | $$| $$_  $$_  $$     /$$__  $$|  $$ /$$/ /$$__  $$
| $$  | $$| $$  | $$|  $$$$$$   | $$    | $$$$$$$$| $$  \__/  | $$    | $$| $$  | $$| $$ \ $$ \ $$    | $$$$$$$$ \  $$$$/ | $$$$$$$$
| $$  | $$| $$  | $$ \____  $$  | $$ /$$| $$_____/| $$        | $$ /$$| $$| $$  | $$| $$ | $$ | $$    | $$_____/  >$$  $$ | $$_____/
| $$$$$$$/|  $$$$$$/ /$$$$$$$/  |  $$$$/|  $$$$$$$| $$        |  $$$$/| $$|  $$$$$$/| $$ | $$ | $$ /$$|  $$$$$$$ /$$/\  $$|  $$$$$$$
|_______/  \______/ |_______/    \___/   \_______/|__/         \___/  |__/ \______/ |__/ |__/ |__/|__/ \_______/|__/  \__/ \_______/

HSL trojan has come up!!!
-------------------------------------------------------------------------------------------------------------------------------------
This is a HSL trojan/malware.
This malware is very dangerous for non-safety version.
Run it ONLY on a VM.
Do NOT run this on a real PC.
This has HSL GDI effects.
Also it works ONLY on Windows XP 32-bit and 64-bit.
Made in: C++
Creation date: January 4th, 2026
Similar to Purgatorium, but in inverting color rotating effect and texts and question icon windows... so look closely.
3D Donut errored-icon is also similar to Aether by JhoPro.