Tested only on Windows 10 (the simple version)
This is a simple and harmless malware called simply simplegdi.exe
Made by anotheraccount (and NotCCR for the simple GDI)
It's simply the simplest GDI that the simplest simple people have ever simply seen.
Credits to malsteve527 for his simple Hue shift function
Epilepsy warning! (it's simple)
Simply made in Dev-C++
For simple skidders: please simply credit to me if you use the simple source code!

"Simple GDI." - NotCCR















Note: This is a joke malware, it's not meant to make fun of NotCCR/Nuclear_GDI.