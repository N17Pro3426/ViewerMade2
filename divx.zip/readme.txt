divx.exe by pan koza 2
Works on Windows XP-11 (XP is recommended)
The non-safety version will destroy your PC when you run it, I'm not responsible for any damages, because this malware was created for educational purposes only, not to damage other people's computers!
Run only in a virtual machine!
Credits to EthernalVortex for the PRGBQUAD system
Credits to ArTicZera and wipet for the HSL
Credits to Malsteve527 for the Hue function
This malware contains flashing lights and earrape, NOT for epilepsy