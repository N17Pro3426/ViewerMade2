Tera+RGB.exe
This is my new malware
This malware is very dangerous for non-safety version.
This trojan can harm your computer and wipe the C: drive and MBR.
Use it ONLY on a Virtual Machine.
Credits to N17Pro3426 for kindness
Please note that the creator (KozaResponding2) is NOT responsible for ANY damages.
Made in: C#
Also, it's a modification of Tera Bonus.