__  ______  ____  
\ \/ /  _ \/ ___| 
 \  /| |_) \___ \ 
 /  \|  __/ ___) |
/_/\_\_|   |____/

Made by lipkoza
My new malware
Bye!