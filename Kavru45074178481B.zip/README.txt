You just downloaded Kavru45074178481B.exe and thank you.

Info about malware below:
Made in C++
8 payloads (short malware)
Made by Kavru (solo)
Started on October 29th and finished on October 31th.

A few side notes, some effects might lag (I forgot which payload(s) it was)
And yeah, enjoy!
Also run it as administrator.



- Kavru :D