                       _       _          _                ###### #    # ###### 
                      | |     (_)        | |               #       #  #  #      
 _____      _____   __| |_ __  ___      _| |__   __ _      #####    ##   #####  
/ __\ \ /\ / / _ \ / _` | '_ \| \ \ /\ / / '_ \ / _` | ### #        ##   #      
\__ \\ V  V / (_) | (_| | | | | |\ V  V /| |_) | (_| | ### #       #  #  #      
|___/ \_/\_/ \___/ \__,_|_| |_|_| \_/\_/ |_.__/ \__, | ### ###### #    # ###### 
                                                 __/ |
                                                |___/
                          
To run file create shortcut to .exe file and move it anywhere you want.
When you press Yes, it'll run virus and if you click No, it'll do smth secret lol
Made by Rectoria