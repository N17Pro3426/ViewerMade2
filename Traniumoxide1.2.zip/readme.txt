████████╗██████╗  █████╗ ███╗   ██╗██╗██╗   ██╗███╗   ███╗ ██████╗ ██╗  ██╗██╗██████╗ ███████╗ ██╗   ██████╗ 
╚══██╔══╝██╔══██╗██╔══██╗████╗  ██║██║██║   ██║████╗ ████║██╔═══██╗╚██╗██╔╝██║██╔══██╗██╔════╝███║   ╚════██╗
   ██║   ██████╔╝███████║██╔██╗ ██║██║██║   ██║██╔████╔██║██║   ██║ ╚███╔╝ ██║██║  ██║█████╗  ╚██║    █████╔╝
   ██║   ██╔══██╗██╔══██║██║╚██╗██║██║██║   ██║██║╚██╔╝██║██║   ██║ ██╔██╗ ██║██║  ██║██╔══╝   ██║   ██╔═══╝ 
   ██║   ██║  ██║██║  ██║██║ ╚████║██║╚██████╔╝██║ ╚═╝ ██║╚██████╔╝██╔╝ ██╗██║██████╔╝███████╗ ██║██╗███████╗
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝ ╚═════╝ ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝ ╚═╝╚═╝╚══════╝
Yeah, an update.
Literally what can i do to myself when i love making this? LMAO
Welcome again... Tranium or anybody else seeing this...
This is an update of Traniumoxide.exe
Made by Hexademical (me ofc)
It basically does the same things as in the previous version, but something changed.
A funny-destruction message has been added on the full execution of malware.
Added cursor shaking + 9 system icons appearing
Added a write icon effect, it will show itself when the first sound starts.
The destruction things are the same... added new effects and sounds.
Don't launch this malware on a physical device, cuz you'll kill it.
Instead, launch this on a virtual machine with snapshot or a clone created.
Good luck.
- Hexademical