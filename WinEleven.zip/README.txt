 __      __.__       ___________.__                                                      
/  \    /  \__| ____ \_   _____/|  |   _______  __ ____   ____       ____ ___  ___ ____  
\   \/\/   /  |/    \ |    __)_ |  | _/ __ \  \/ // __ \ /    \    _/ __ \\  \/  // __ \ 
 \        /|  |   |  \|        \|  |_\  ___/\   /\  ___/|   |  \   \  ___/ >    <\  ___/ 
  \__/\  / |__|___|  /_______  /|____/\___  >\_/  \___  >___|  / /\ \___  >__/\_ \\___  >
       \/          \/        \/           \/          \/     \/  \/     \/      \/    \/ 

[ENG]
Malware name: WinEleven.exe
Malware type: Destructive
Run it at your own risk!
The creator (DeX2PM) is not responsible for any damage to PC
This malware can kill MBR, crash your system and delete your files
After running it, you can see skidded GDI effects and loud bytebeat sounds before it starts as an administrator rules and close UAC
(recommended to run it on a Virtual Machine).

[RUS]
Название вируса: WinEleven.exe
Тип вируса: Деструктивный
Запуская вы рискуете потерять систему, файлы и МБР
Разработчик не в ответе за ЛЮБЫЕ проблемы с системой
Вирус может убить систему вместе с МБР стереть файлы и все другое
После запуска вирус обходит защиту УАК и запускается с правами администратора после этого вы увидите GDI эффекты и услышите bytebeat музыку
(рекомендуется запускать на виртуальной машине).
                                                                                                                       