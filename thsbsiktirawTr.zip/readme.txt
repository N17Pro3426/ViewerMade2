thsbsiktirawTr.exe
My new short virus and again skidded.
8 payloads lasting 4 minutes.
Doesn't create an MBR and it's safe.