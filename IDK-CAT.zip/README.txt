Warning!
IDK-CAT.exe is NOT a game, it's a malware!
This executable won't destroy your PC!
And ok...
 _____ _____  _  __      _____       _______ 
|_   _|  __ \| |/ /     / ____|   /\|__   __|
  | | | |  | | ' /_____| |       /  \  | |
  | | | |  | |  <______| |      / /\ \ | |
 _| |_| |__| | . \     | |____ / ____ \| |
|_____|_____/|_|\_\     \_____/_/    \_\_|

Malware name: IDK-CAT.exe
Malware type: Safety
The creator (DeX2PM) is NOT responsible for ANY damage to your PC!

And classic:
(<UwU>) Nyan! :3 :) :( %: ^_^ >_< *_*