 _   _       _                           _     _                     
| | | |     (_)                         (_)   | |                    
| | | |_ __  _  ___  _ __ ___   _____  ___  __| | ___   _____  _____ 
| | | | '_ \| |/ _ \| '_ ` _ \ / _ \ \/ / |/ _` |/ _ \ / _ \ \/ / _ \
| |_| | | | | | (_) | | | | | | (_) >  <| | (_| |  __/|  __/>  <  __/
 \___/|_| |_|_|\___/|_| |_| |_|\___/_/\_\_|\__,_|\___(_)___/_/\_\___|
----------------------------------------------------------------------
This is my crazy HSL malware I ever made.
This malware is very dangerous for non-safety.
Do NOT run this in your real computer, just run it ONLY in a VM.
Credits to gabrodev for MBR and 1 payload
Credits to Kavru for colorful GDI text.
Made in: C#
I'm NOT responsible for ANY damages!
Anyways, take care.