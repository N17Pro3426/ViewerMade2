____________ _____ _____  _____ _   _ 
|  _  \ ___ \  _  |  __ \|  ___| \ | |
| | | | |_/ / | | | |  \/| |__ |  \| |
| | | |    /| | | | | __ |  __|| . ` |
| |/ /| |\ \\ \_/ / |_\ \| |___| |\  |
|___/ \_| \_|\___/ \____/\____/\_| \_/

This malware is very dangerous for non-safety version.
It will cause data loss or makes the computer likely unbootable.
Made in: C#, .NET Framework
Malware type: GDI trojan
Please note that this trojan is very dangerous and I'm NOT responsible for ANY damages.
Credits to: N17Pro3426