Tested only on Windows 10
This is a harmless malware called Intermix.exe
Made by anotheraccount
It randomizes the payloads and its effects!
So it's different everytime you run it.
Also, this is still in beta so expect some bugs, crashes & stuff.
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...