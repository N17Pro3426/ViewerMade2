olpzpzl.exe by VietNamLover.
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 14 payloads.
Differences compared to olthaltlzpz.exe by pankoza:
Changed all texts and bytebeats.