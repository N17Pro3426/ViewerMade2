NEDİYOOLUM.exe
Bytebeats used:
t>>(6115*t*(t>>9|9)>>12) 11025 hz
t*((t>>10|t>>4)&11&t>>7) 11025 hz
t*(t*t>>8&t>>12)|t>>3 8000 hz
t*t>>13^t*5*t>>12 8000 hz
t^t*(3735936685>>(t>>10&10)&12)|t>>2 32000 hz
2<<(t*t>>16)>>t 8000 hz
t*(t>>6&t>>2)>>(t>>16) 16000 hz
t*t>>(t*t>>(t>>9)^t)/t  8000 hz
2*(t*16/((10^(7&t>>15))+3)&99)|t 32000 hz (Sustain Epic version: 2*(t*16/((10^(7&t>>15))+3)&99))
If you want to add this to your GitHub repository, put it both as .exe and .cpp.
Please PLEASEEEEEEEEEEEEEEEEEEEEEEE-