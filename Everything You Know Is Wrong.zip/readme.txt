Everything You Know Is Wrong.exe
Made by lipkoza
My new malware
This C++ and HSL payload
Bye!