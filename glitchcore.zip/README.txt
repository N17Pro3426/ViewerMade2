░██████╗░██╗░░░░░██╗████████╗░█████╗░██╗░░██╗░█████╗░░█████╗░██████╗░███████╗░░░███████╗██╗░░██╗███████╗
██╔════╝░██║░░░░░██║╚══██╔══╝██╔══██╗██║░░██║██╔══██╗██╔══██╗██╔══██╗██╔════╝░░░██╔════╝╚██╗██╔╝██╔════╝
██║░░██╗░██║░░░░░██║░░░██║░░░██║░░╚═╝███████║██║░░╚═╝██║░░██║██████╔╝█████╗░░░░░█████╗░░░╚███╔╝░█████╗░░
██║░░╚██╗██║░░░░░██║░░░██║░░░██║░░██╗██╔══██║██║░░██╗██║░░██║██╔══██╗██╔══╝░░░░░██╔══╝░░░██╔██╗░██╔══╝░░
╚██████╔╝███████╗██║░░░██║░░░╚█████╔╝██║░░██║╚█████╔╝╚█████╔╝██║░░██║███████╗██╗███████╗██╔╝╚██╗███████╗
░╚═════╝░╚══════╝╚═╝░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝░╚════╝░░╚════╝░╚═╝░░╚═╝╚══════╝╚═╝╚══════╝╚═╝░░╚═╝╚══════╝
Made in Japan

これはマルウェアであり、MBR（ブートセクターまたはマスターブートレコード）を上書きします。
念のため実行際に2回警告メッセージが出ますがいかなる理由があっても何も知らない場合は直ちに削除することを推奨します。
これはマルウェアです。PCを起動不能にさせます。
もし実機で実行する場合は回復ドライブ（リカバリUSB）を準備しておくことを推奨します。
もし実機で実行したくないけどどうしても実行したいときは仮想環境での実行を推奨します。
※仮想環境が使用できるソフトは以下に記載。

しるまチャンネルより

VMware Workstation Player 17:
ダウンロード: https://www.techspot.com/downloads/downloadnow/1969/?evp=aeae0304eece96beff922bd24ecbb849\&file=2171
動画: https://www.youtube.com/watch?v=wk6hxrA2DRs

VirtualBox:
ダウンロード: https://www.virtualbox.org/
動画: https://www.youtube.com/watch?v=s2JdqTrP78s

This is malware that overwrites the MBR (Master Boot Record or boot sector).
Just in case, a warning message will appear twice upon execution, but for any reason, 
if you don't know anything about it, it is recommended to delete it immediately. 
This is malware and can make your PC unbootable. If you are going to run it on actual hardware, it is recommended to prepare a recovery drive (recovery USB). 
If you do not want to run it on actual hardware but still want to execute it, it is recommended to run it in a virtual environment. 
*Software that can use a virtual environment is listed below.

by Shiruma Channel

VMware Workstation Player 17:
Download: https://www.techspot.com/downloads/downloadnow/1969/?evp=aeae0304eece96beff922bd24ecbb849\&file=2171
Video: https://www.youtube.com/watch?v=wk6hxrA2DRs

VirtualBox:
Download: https://www.virtualbox.org/
Video: https://www.youtube.com/watch?v=s2JdqTrP78s