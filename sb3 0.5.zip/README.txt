░██████╗██████╗░██████╗░  ██╗░░░██╗░█████╗░░░░███████╗
██╔════╝██╔══██╗╚════██╗  ██║░░░██║██╔══██╗░░░██╔════╝
╚█████╗░██████╦╝░█████╔╝  ╚██╗░██╔╝██║░░██║░░░██████╗░
░╚═══██╗██╔══██╗░╚═══██╗  ░╚████╔╝░██║░░██║░░░╚════██╗
██████╔╝██████╦╝██████╔╝  ░░╚██╔╝░░╚█████╔╝██╗██████╔╝
╚═════╝░╚═════╝░╚═════╝░  ░░░╚═╝░░░░╚════╝░╚═╝╚═════╝░
It's based off the scratch malware called sb3.exe.
I already made a sb3 malware, so this is 0.5 version.
<------------------------------------------------------------------------->
It's not skidded, but some effects are similar to other malwares!
Scratch malware (NOT mine): https://scratch.mit.edu/projects/1164110970/
My YouTube channel: https://www.youtube.com/@Trisodium