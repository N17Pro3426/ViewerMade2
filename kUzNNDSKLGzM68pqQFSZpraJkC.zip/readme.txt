kUzNNDSKLGzM68pqQFSZpraJkC.exe
Made by lipkoza
My new malware
Bye!