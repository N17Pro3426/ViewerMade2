abraham106.exe
Made by abraham106
Run in VM, also it runs in Windows 7, 10 and 11
I made this all by my own
Started: July 1st
Done: July 10th
Enjoy!