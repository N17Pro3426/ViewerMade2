Ai Hoi.exe by Nimboot-m4m
Damage rate: Destructive
Creation date: January 14, 2026
Programming language: C++

This malware is very dangerous.
It will erase all your data and damage your operating system if you run it on your real PC. 
I'll NOT be responsible for ANY damages!

Works better on Windows 7.
Works on Windows Vista-11.