__________                                   .__                                 
\______   \_____ ____________    ____   ____ |__|____        ____ ___  ___ ____  
 |     ___/\__  \\_  __ \__  \  /    \ /  _ \|  \__  \     _/ __ \\  \/  // __ \ 
 |    |     / __ \|  | \// __ \|   |  (  <_> )  |/ __ \_   \  ___/ >    <\  ___/ 
 |____|    (____  /__|  (____  /___|  /\____/|__(____  / /\ \___  >__/\_ \\___  >
                \/           \/     \/               \/  \/     \/      \/    \/ 

これはGDImalwareで画面に描画を行ってからMBRを上書きするプログラムです。これはセキュリティ研究目的に作成されています。
いかなる理由があっても実機や重要なファイルがあるパソコンなどでは絶対に実行しないでください。このファイルを共有したり、二次配布しないでください。
改ざん、悪用も厳禁です。実行する際は必ず仮想環境で実行することをお勧めします。

This is a GDI malware program that performs screen drawing effects and then overwrites the MBR.
It was created for security research purposes only.
Under no circumstances should it be executed on a physical machine or on any computer containing important files.
Do NOT share or redistribute this file.
Modification and malicious use are strictly prohibited.
It's strongly recommended that you run this program only in a virtual machine environment.