Depression.exe by Nimboot-m4m
Programming language: C++
Danger level: High

Make sure you run it on a virtual machine.
If you run it on your real computer, your computer will crash.
I'm NOT responsible for ANY damages.