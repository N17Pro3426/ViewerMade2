          _______  _______ _________ _______  _       _________ ______   _______     _______           _______ 
|\     /|(  ___  )(  ____ )\__   __/(  ___  )( (    /|\__   __/(  __  \ (  ____ \   (  ____ \|\     /|(  ____ \
| )   ( || (   ) || (    )|   ) (   | (   ) ||  \  ( |   ) (   | (  \  )| (    \/   | (    \/( \   / )| (    \/
| |   | || |   | || (____)|   | |   | (___) ||   \ | |   | |   | |   ) || (__       | (__     \ (_) / | (__    
( (   ) )| |   | ||     __)   | |   |  ___  || (\ \) |   | |   | |   | ||  __)      |  __)     ) _ (  |  __)   
 \ \_/ / | |   | || (\ (      | |   | (   ) || | \   |   | |   | |   ) || (         | (       / ( ) \ | (      
  \   /  | (___) || ) \ \__   | |   | )   ( || )  \  |___) (___| (__/  )| (____/\ _ | (____/\( /   \ )| (____/\
   \_/   (_______)|/   \__/   )_(   |/     \||/    )_)\_______/(______/ (_______/( )(_______/|/     \|(_______/
                                                                                 |/                            

This is a huge collab that I made with 3 other people...
Thanks to crzxymint, UltraDasher965 and N17Pro3426 for participating in this malware collab.
I appreciate it so much.
This malware turned out in 30 effects.
This malware is NOT compatible with Windows XP, so don't even try.
OS's that this malware can be executed in: Windows Vista-11 x64
Hexademical: 13 payloads
N17Pro3426: 8 payloads
UltraDasher965: 4 payloads
crzxymint: 5 payloads
I don't even know what to say anymore.
Message to N17Pro3426: Дякую за те що прийняв участь в цьому.
Enjoy this monstrosity!
:D