NN    N İ   CCCC  OOOOO  TTTTTTT İ NN     N EEEEEEE   EEEEEEE X    X EEEEEEE
N N   N    C     O     O    T      N  N   N E         E        X  X  E
N  N  N İ C     O       O   T    İ N   N  N EEEEEEE   EEEEEEE   XX   EEEEEEE
N   N N İ  C     O     O    T    İ N    N N E         E        X  X  E
N     N İ   CCCC  OOOOO     T    İ N      N EEEEEEE . EEEEEEE X    X EEEEEEE
Made by lipkoza
My new malware
Bye!