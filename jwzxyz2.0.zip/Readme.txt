jwzxyz2.0.exe by VietNamLover.
This GDI malware has 10 payloads.
This is a safe GDI malware, so you can run it on your real PC.
Update of jwzxyz.exe:
Changed all texts and bytebeats.