 _____            _                   _   _                            
|  __ \          | |                 | | (_)                           
| |  | | ___  ___| |_ _ __ _   _  ___| |_ _  ___  _ __    _____  _____ 
| |  | |/ _ \/ __| __| '__| | | |/ __| __| |/ _ \| '_ \  / _ \ \/ / _ \
| |__| |  __/\__ \ |_| |  | |_| | (__| |_| | (_) | | | ||  __/>  <  __/
|_____/ \___||___/\__|_|   \__,_|\___|\__|_|\___/|_| |_(_)___/_/\_\___|

このマルウェアはしるまチャンネルによって作成されたものです。
これは主に教育・セキュリティ研究目的に作成されたものです。
悪意があるものではありません。
もしこの実行ファイルが何かわからなかったら絶対に実行しないでください！
これはマルウェアです。
MBRを上書きし、PCを起動させなくするシステムが仕込まれています！
なにも知らない場合直ちに削除してください！
そして発行者・製作者は何かあったとしても一切の責任を負いません。
自己責任で使用してください。
もし何か不具合が起きている場合はすぐにファイルを削除してください。
あなたのPCが危険にさらされる可能性があります。
そして仮想環境での実行を推奨します。

This malware was created by Shuruma Channel.
It was created primarily for educational and security research purposes and is not malicious.
If you do not understand what this executable file is, please do not run it under any circumstances!
This is malware.
It is designed to overwrite the MBR and prevent the PC from booting!
If you are unaware of anything, delete it immediately!
The publisher and creator assume no responsibility for any issues that may arise.
Use it at your own risk.
If there are any problems, delete the file immediately.
Your PC may be at risk.
Running it in a virtual environment is recommended.