ᴜuııaıяa̛רs_ııan̍ר.exe
Made by ConduciveGDI
My first layered window GDI malware.
Name: ᴜuııaıяa̛רs_ııan̍ר(บนแลเกสาร_แลท่า)
Romanized: bonlaekesan_laetha
IPA: bon˧lɛː˧keː˧saːn˩˩˦.lɛː˧tʰaː˥˩