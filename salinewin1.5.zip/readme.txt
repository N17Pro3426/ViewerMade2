salinewin.exe by pankoza
This is a GDI malware
This is very dangerous for the non-safety version
The non-safety version will corrupt the MBR and make the PC unusable.
Run it ONLY on a virtual machine.
I'm NOT responsible for ANY damages
Credits to GetMBR and Malsteve527 for the Hue function
Credits to EthernalVortex for PRGBQUAD

Changelog:
1.0 version: Initial release
1.5 version:
1. Bugfix release
2. Replace GetMBR's Hue function with Malsteve527's one
3. Change the sine waves payload
4. Fixed bugs in the MBR (hopefully make it work on PCs with InsydeH2O BIOS and use a newer MBR overwriting code that doesn't do an unnecessary loop that makes HDDs heat and shortens the lives of SSDs)
5. Newer Task Manager disabling code that doesn't rely on Command Prompt or Registry Editor