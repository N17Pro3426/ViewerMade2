1x3x5x6.exe by Kavru
Short, but extremely destructive GDI malware (9 payloads)

Made by: i literally just said my name lol
Made in: C++
Danger rate: Weapon of Mass Destruction. (Massive/Insane/Destructive)
Credits to the team 1x3x5x6 (Roblox) for the inspiration of the name.
Works best in: Windows 7, but Vista-11 is supported.

Note: 
This is NOT a joke! It will absolutely wreck the shit out of your VM. Made ONLY for educational
and entertainment purposes. This is EXTREMELY destructive as said above. Make sure to run
as administrator btw...