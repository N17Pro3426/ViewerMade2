Xarlnium.exe
My new malware
Credits to TijnAG07 for the 1st GDI payload of RGBQUAD waves
Credits to karusthecoolcoder for the MBR
Also, this is layered window malware made in C++