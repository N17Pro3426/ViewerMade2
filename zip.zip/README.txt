zip.exe by abraham106
Works best on Windows 10 or 11
On Windows 7 it might be good
If GDI effects will stop in Windows 7, then go to Windows 10 or 11
Skidded? No, it's not skidded.
Safe? Yes, it's safe.
It doesn't work on Windows Vista, 95, 98, XP and bellow Vista 
Run it on a VM!