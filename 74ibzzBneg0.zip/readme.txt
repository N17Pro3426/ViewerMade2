########    #   # #               ######                  #####
       #   ##     #               #     #                #     #
      #   # #   # #               #     #                #     #
     #   #  #   # #     #### #### ######  # #   ##   ### #     #    ##  #   #  ## 
    #   #   #   # ####     #    # #     # ## # #  # #  # #     #   #  #  # #  #  #
    #  ######## # #   #  ##   ##  #     # #  # #### #### #     #   ####   #   ####
    #       #   # #   # #    #    #     # #  # #       # #     #   #     # #  #
    #       #   # ####  #### #### ######  #  #  ### ###   #####  # #### #   # ####

(It looks good if you stretch the window btw)
74ibzzBneg0.exe made by Arturs12/Arturs887
I made this using Dev-C++ 5.11.
It was originally going to be Visual Studio 2019, but it just won't work properly for me.
It's skidded and I don't care if I use unoriginal things like bytebeats, credits to all people that I skidded from.
It's safe, so you can run this on your main PC if you want, but I recommend a VM if you don't trust me.
This is longer than pck.exe by 10 payloads.
Fun fact: This was originally going to be 73 payloads, but it's been cut to 25, because I won't have any other payloads to use.
Fun fact 2: The name of this malware is a YouTube video ID.


















































































N17Pro3426, if you're reading this, rank this skidded malware out of 100. (e.g. 50/100)