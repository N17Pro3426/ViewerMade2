Tested only on Windows 10
This is a harmless malware called BleuLejendTales1234.exe
Made by anotheraccount
Epilepsy warning, also it will move your mouse!
It's also named after the youtube account "BleuLejendTales1234" (credits to him).
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...