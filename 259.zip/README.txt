259.exe
It's a joke malware, so there's no real effort put into this.
Made in: C
Damage rate: Extremely low
Made by: Kavru
Note: Enjoy, also i'm not sure if it has an end so idk, it might be endless.