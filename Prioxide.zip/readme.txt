Tested only on Windows 10
This is a harmless malware called Prioxide.exe
Made by anotheraccount
Inspired by Monoxide.exe and the payloads are randomized
Credits to malsteve527 for his Hue shift function and some effects
Epilepsy warning!
It will also move your mouse!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...















"Simple GDI." - NotCCR