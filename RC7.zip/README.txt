RC7.exe
Made by: Kavru
Damage rate: Extremely high
Made in: C++
No credits.
Works best in: Windows 7, 8, and 8.1

Note: 
This is my second destructive malware and if ran it will have you reinstalling Windows all over again...
I forgot to set as critical so just restart your PC after🥀
uhhhh yeah it does overwrite MBR ig and also run as administrator so it works.

Enjoy! :D