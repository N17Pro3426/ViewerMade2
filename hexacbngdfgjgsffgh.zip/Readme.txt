hexacbngdfgjgsffgh.exe by VietNamLover
Credits to Clutter xmodz for the name
The non-safety version will destroy your PC, so run it ONLY on a VM.
The safe version won't destroy it, so you can run it without VM.
This GDI malware has 20 payloads.
Differences compared to Hatsunium.exe by XUGE:
Changed all texts, some bytebeats and more.