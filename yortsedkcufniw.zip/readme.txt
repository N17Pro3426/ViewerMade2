yortsedkcufniw.exe by redkidd, Kimiberry64 and VMmalware
Use this program responsibly!
We, the creators are NOT responsible for ANY damage.