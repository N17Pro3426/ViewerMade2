Malware name: Instruction.exe
Supported operating systems: Windows XP (64-bit) and above
Creator: uu-taskmgr
Programming language: C++
Creation date: January 11, 2026
Note:
1) It should be noted that due to limitations in computer configuration, operating system and application compatibility, the effects may vary slightly
   on different computers. Delays, intervals, or overlaps in effects are normal and will not affect the occurrence or damage of computer viruses.
2) If it is running in a virtual machine, try not to change the virtual machine's resolution during operation, otherwise some problems may occur with
   the special effects (such as incomplete display, special effects not displaying, etc.).
3) This program is now well compatible with high-DPI devices and will not cause incomplete or misaligned effects in most cases.
4) The files are divided into harmful and harmless versions (the corresponding English will be after the file name; harmful means harmful and harmless
   means harmless). Do NOT run the harmful version on other people's computers. If it causes losses, you will be responsible for the corresponding
   legal liability. The creator will NOT be held responsible.
5) To run a malicious version of the program, you need to right-click and run it as administrator; otherwise, it may not be able to cause damage.
6) This program may be blocked by antivirus software (including the harmless version), so please ensure that all antivirus software is turned off
   before running it.
7) During testing, it was found that the program may malfunction when running on some older systems or devices with poor configurations, such as sound
   effects not playing, special effects not displaying properly or a dialog box popping up saying that the program has stopped working.
8) If you find any bugs in this program, please contact the author immediately and explain the situation so that the bugs can be fixed in a timely
   manner.
9) This program also left some Easter eggs. Type "/?" for help.
https://space.bilibili.com/544022796?spm_id_from=333.1007.0.0
QQ:3133614431
Enjoy the anticipation.

产品名称：Instruction.exe
支持的操作系统：Windows XP (x64) 及以上
作者：VS-taskmgr
编写语言：C++
编写时间：2026.1.11
说明：
1：需要注意的是，受限于电脑配置、操作系统、应用程序兼容性等因素，在不同的电脑下运行的效果可能略有不同。如果出现特效延迟、特效间隔、特效重叠，均属于正常现象，不会影响电脑病毒的发作或破坏。
2：如果是在虚拟机运行的，那么在运行过程中，尽量不要让虚拟机的分辨率发生改变，否则特效可能会出现一些问题（如显示不全、特效不显示等）。
3：此程序目前已经能较好地兼容高DPI设备，在绝大部分情况下不会出现特效显示不全或错位的现象。
4：文件分为有害版和无害版（文件名称后面会有对应的英文，harmful为有害版，harmless为无害版），有害版请不要在他人电脑上运行，如果造成损失，你需要承担相应法律责任，电脑病毒作者不负此责任。
5：运行有害版程序需要右键以管理员身份运行，否则可能会无法起到破坏性作用。
6：此程序可能会被杀毒软件拦截（也包括无害版），因此在运行之前请确保杀毒软件均已关闭。
7：在测试过程中发现，该程序在某些较低版本的系统或配置较差的设备运行时可能会出现异常，如音效无法播放，特效无法正常显示，或弹出程序已停止工作的对话框等。
8：若发现此程序有bug，请第一时间与作者取得联系，并说明状况，以便及时修复bug。
9：本病毒还留下了一些彩蛋，输“/？”以获取帮助.
https://space.bilibili.com/544022796?spm_id_from=333.1007.0.0
QQ:3133614431
尽享期待。