Lodine.exe
New virus made by abraham106
Run in a VM or add side effects to your computer :)
I'm NOT responsible to side effects on your computer!
There's no warning, but this text file is the warning y