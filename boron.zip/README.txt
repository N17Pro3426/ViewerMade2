boron.exe by abraham106
My YouTube channel: https://www.youtube.com/@Abrahamtestgdiviruses
My YouTube channel 2: https://www.youtube.com/@Abraham34535
Breaks your computer and it's not skidded one of the payloads.
I made this and nobody helped me enjoy it :)
Place the .exe in the same directory as the .wav files.































































Hi fr4ctalz, N17Pro3426, Crypto NWO and RainflowBoi, if you are reading this, hi.
Also, I can't believe it's almost the end of the year!