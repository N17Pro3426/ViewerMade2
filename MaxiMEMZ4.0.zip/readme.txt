This is malicious software.
Do NOT run unless you know the risks.