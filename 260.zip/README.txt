260.exe
Not skidded!!!
Made by: Kavru (no help)
Made in: C# (my first C# malware)
A 21-22 payload malware made in like 2-3 hours (extra delays by day caused by debugging and testing from errors.)
No credits.
Works on: Windows 7, 8 and 8.1
I feel like turning this into a number series starting at 259 which was my last malware, so now we at 260 and so on.
Also, epilepsy warning of course!
Enjoy!