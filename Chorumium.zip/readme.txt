  _____ _                               _                 
 / ____| |                             (_)                
| |    | |__   ___  _ __ _   _ _ __ ___  _ _   _ _ __ ___  
| |    | '_ \ / _ \| '__| | | | '_ ` _ \| | | | | '_ ` _ \ 
| |____| | | | (_) | |  | |_| | | | | | | | |_| | | | | | |
 \_____|_| |_|\___/|_|   \__,_|_| |_| |_|_|\__,_|_| |_| |_|.exe

Made by MalvareKing & N17Pro3426
Programing language: C++
MBR is a Mandelbrot
This is a GDI malware
This is very dangerous for the non-safety version
The non-safety version will corrupt the MBR and make the PC unusable.
Run it ONLY on a virtual machine!
The creators are NOT responsible for ANY damages!!!
Also make sure you have the 2 .wav files from the .zip file and do NOT delete them, because some sounds did NOT work for some reason. :/
If .wav files are deleted, then some sounds won't play the audio.
:D