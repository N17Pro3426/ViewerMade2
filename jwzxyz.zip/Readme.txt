jwzxyz.exe by VietNamLover.
This GDI malware has 10 payloads.
This is a safe GDI malware, so you can run it on your real PC.
Differences compared to jwzyexgnlc.exe by pankoza:
Changed texts and bytebeats.