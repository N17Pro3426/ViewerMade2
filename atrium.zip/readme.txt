Tested only on Windows 10
This is a harmless malware called atrium.exe
Made by anotheraccount
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...