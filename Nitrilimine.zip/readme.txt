Tested only on Windows 10
This is a harmless malware called Nitrilimine.exe
Made by anotheraccount
Originally was gonna be named Nitrile, but it's almost the same as Nitrite by NotCCR
Credits to malsteve527 for his Hue shift function
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...















"Simple GDI." - NotCCR