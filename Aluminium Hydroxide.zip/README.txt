Aluminium Hydroxide.exe by NimBoot-m4m
Damage rate: Destructive
Made in: C++
Creation date: January 2026

This malware is very dangerous.
It will erase all your data and damage your operating system if you run it on your real PC. 
I'll NOT be responsible for ANY damages!

Works better on Windows 7.
Works on Windows Vista-11.