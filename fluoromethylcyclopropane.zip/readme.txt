fluoromethylcyclopropane.exe
Made by lipkoza in C++
My new malware
If you want to close it, press the Esc key
Bye!