r2crw17w.exe
A malware made by Hexademical (me)
This is a destructive malware that can cause serious damage to your computer.
If you wish to destroy your device, use the destructive version, it will overwrite the boot record, delete boot configuration data and block many useful programs to let your PC live.
Otherwise, if you want to run the safety version, use the safety version, this will NOT do anything to your computer and it will not have an finale payload.
Enjoy this monstrosity I made! (￣▽￣)