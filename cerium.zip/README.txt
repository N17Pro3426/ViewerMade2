 $$$$$$\  $$$$$$$$\ $$$$$$$\  $$$$$$\ $$\   $$\ $$\      $$\     $$$$$$$$\ $$\   $$\ $$$$$$$$\ 
$$  __$$\ $$  _____|$$  __$$\ \_$$  _|$$ |  $$ |$$$\    $$$ |    $$  _____|$$ |  $$ |$$  _____|
$$ /  \__|$$ |      $$ |  $$ |  $$ |  $$ |  $$ |$$$$\  $$$$ |    $$ |      \$$\ $$  |$$ |      
$$ |      $$$$$\    $$$$$$$  |  $$ |  $$ |  $$ |$$\$$\$$ $$ |    $$$$$\     \$$$$  / $$$$$\    
$$ |      $$  __|   $$  __$$<   $$ |  $$ |  $$ |$$ \$$$  $$ |    $$  __|    $$  $$<  $$  __|   
$$ |  $$\ $$ |      $$ |  $$ |  $$ |  $$ |  $$ |$$ |\$  /$$ |    $$ |      $$  /\$$\ $$ |      
\$$$$$$  |$$$$$$$$\ $$ |  $$ |$$$$$$\ \$$$$$$  |$$ | \_/ $$ |$$\ $$$$$$$$\ $$ /  $$ |$$$$$$$$\ 
 \______/ \________|\__|  \__|\______| \______/ \__|     \__|\__|\________|\__|  \__|\________|
You have ONLY 1 shot, User.
==========================================================================================================
Hello everyone! This is my second GDI malware ever called cerium.exe.
It's a sequel to cesium, my first malware. I call cerium cesium's brother.
This malware took me about 3 days to make, and I wrote it in C#.

This is the update 1.1 of it. Key changes:
1. bugfixes
2. optimizations
3. ~60% of code rewritten
4. small tweaks
Pretty much like cesium

This malware was private, but now it's public along with cesium, since I reached 1K subs on my YouTube channel! (@silverjetes)
It is also open source on my GitHub account. (silverjetes)

In order to run it, install .NET Framework 4.0. Download link:
https://download.microsoft.com/download/9/5/a/95a9616b-7a37-4af6-bc36-d6ea96c8daae/dotNetFx40_Full_x86_x64.exe

If you run Windows 8 or greater, it is already preinstalled.
Windows XP/7 with Basic theme recommended for fast GDI performance.
==========================================================================================================
Credits to ClutterTech (CYBER SOLDIER), MalwareLab150 (Mattia), GetMBR (Isolynx) & holymacaroniwhybruh.
Inspired by Monoxide.exe from wipet

Special thanks to CiberBoy for help with many payloads including the GDI ones and to MalwareLab150 for making the MBR.
==========================================================================================================
by silverjetes <3
02/25