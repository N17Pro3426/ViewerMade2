Satenufel.exe
Created on July 1st, 2022
I coded everything based on 1920×1080 resolution
This malware works correctly on Windows XP
There are more than 30 payloads!
Creator: Datriunus#6323
*This is my LAST malware*
I stopped making malwares.