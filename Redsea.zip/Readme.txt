Redsea.exe by Wooshydudebro
I was lazy to add sound :(

Malware name: it is at the fucking top
Malware type: a fucking trojan
Works best on Windows XP or newer, I do suggest using Windows XP for fast GDI
Made in Visual Studio 2022 + Windows XP support
Do NOT compile or run this if you do NOT know the risks!!!

Simple GDI. - NotCCR /j