Uniomoxide.exe
My new HSL malware
Credits to gabrodev for the MBR
Credits to Kavru for the GDI payloads