SorryNotSorry!.exe
This is my horror trojan called SorryNotSorry!.exe and it has flashy stuff.
I hope you enjoy this malware if you test or review it.
Made by Heizenn

Some fun facts about this trojan:
1. This horror trojan was made in 1 or 2 weeks
2. It oddly looks like Clutt6.6.6.exe

Features:
1. MBR corruption
2. File encryption via AES
3. Different payloads for supported and unsupported OS versions
4. GDI

Compatibility:
Windows 10 (OS tested on) and 11
Older Windows versions that aren't Vista or older.