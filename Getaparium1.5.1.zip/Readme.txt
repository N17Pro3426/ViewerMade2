Getaparium1.5.1.exe by VietNamLover.
Don't run this malware on your real PC!
This GDI malware has 18 payloads.
Update 2 of Getaparium.exe:
Changed all texts and added destructive stuff.
Maybe I'll never make safety malwares anymore.