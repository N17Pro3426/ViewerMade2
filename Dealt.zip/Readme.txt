Dealt.exe by VietNamLover.
Don't run this malware on your real PC!
This GDI malware has 10 payloads.
This is a remake of wgwcpdpgbf.exe by pankoza and Delta.exe by VietNamLover (me).
Enjoy! =)