██╗      ██████╗  ██████╗ █████╗ ██████╗ ███╗   ███╗██╗██╗   ██╗███╗   ███╗
██║     ██╔═══██╗██╔════╝██╔══██╗██╔══██╗████╗ ████║██║██║   ██║████╗ ████║
██║     ██║   ██║██║     ███████║██║  ██║██╔████╔██║██║██║   ██║██╔████╔██║
██║     ██║   ██║██║     ██╔══██║██║  ██║██║╚██╔╝██║██║██║   ██║██║╚██╔╝██║
███████╗╚██████╔╝╚██████╗██║  ██║██████╔╝██║ ╚═╝ ██║██║╚██████╔╝██║ ╚═╝ ██║
╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═════╝ ╚═╝     ╚═╝╚═╝ ╚═════╝ ╚═╝     ╚═╝
Malware name: locadmium
Damage rate: desctructive 
Programming language: C++
Works on Windows XP-11
The icon is: https://www.bing.com/images/search?view=detailV2&ccid=6n1Zbe2m&id=F33366750AA32525CB092779E4838DA5D1F7DB0F&thid=OIP.6n1Zbe2m0LqekS6l4a3Q5AHaHa&mediaurl=https%3A%2F%2Fgyazo.com%2Fa4abc5fdb965d1b97db38453012efc73%2Fthumb%2F1000&cdnurl=https%3A%2F%2Fth.bing.com%2Fth%2Fid%2FR.ea7d596deda6d0ba9e912ea5e1add0e4%3Frik%3DD9v30aWNg%252bR5Jw%26pid%3DImgRaw%26r%3D0&exph=1000&expw=1000&q=Minecraft+icon&FORM=IRPRST&ck=C75A272E243594482D9EB2E0CA344905&selectedIndex=1&itb=1&cw=1687&ch=860&ajaxhist=0&ajaxserp=0
Used icon to convert: https://www.freeconvert.com/png-to-ico
This software is considered GDI malware and run it ONLY on a VM or safe enviroment to NOT damage your PC! 
Use 2 .wav files for playing sound in 2nd, 3rd, last effect.
