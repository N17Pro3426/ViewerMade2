Tested only on Windows 10
This is a harmless malware called forger.exe
Made by anotheraccount
Credits to malsteve for his Hue shift function
Epilepsy warning!
Made in Dev-C++
For skidders: please credit to me if you use the source code!

idk what else to put here...















"Simple GDI." - NotCCR