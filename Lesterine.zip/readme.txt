Lesterine.exe
Hotspot!!!
It's my first attempt to use HSV for image manipulation.
Its goal is to overwite systems and user files.