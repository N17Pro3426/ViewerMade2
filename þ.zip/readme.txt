Tested only on Windows 10
This is a harmless malware called þ.exe
Made by anotheraccount
Epilepsy warning!
Made in Dev-C++
Icon made with Bittal (by ChrisRM_380)
For skidders: please credit to me if you use the source code!

idk what else to put here...