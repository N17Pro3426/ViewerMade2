Getaparium.exe by VietNamLover.
This GDI malware has 18 payloads.
This is a safe GDI malware, so you can run it on your real PC.
Differences compared to Getaparane.exe by pankoza:
Changed warnings, texts, some bytebeats and some GDI effects.