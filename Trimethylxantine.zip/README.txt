oh buddy... Trimethylxantine.exe

Made by: Kavru
Damage rate: Insane.
Made in: C++
Is this a joke? No, not even close.

Welp... here we are, let's see how your PC does bro.
This is entirely noskid, again epilepsy warning of course.

The warnings tell you what this does and uh good luck to you and your PC.
Enjoy...? (HELL)