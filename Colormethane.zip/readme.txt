  ____      _                              _   _                          
 / ___|___ | | ___  _ __ _ __ ___   ___  | |_| |__   ___  _ __   ___     
| |   / _ \| |/ _ \| '__| '_ ` _ \ / _ \ | __| '_ \ / _ \| '_ \ / _ \    
| |__| (_) | | (_) | |  | | | | | |  __/ | |_| | | | (_) | | | |  __/    
 \____\___/|_|\___/|_|  |_| |_| |_|\___|  \__|_| |_|\___/|_| |_|\___|.exe

It's a dangerous GDI malware with 4 shaders.
The name is a copy of trichloromethane.exe
Made by MalwareKing 
Ended creating: April 4, 2026 at 10:24
Enjoy this malware!!
:D











































Hello N17Pro3426, CryptoNWO, pankoza and more...