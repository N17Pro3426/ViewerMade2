Dude, didn't you learn from what happened last time to your PC? Fine, you wont listen.
734687628764092738947726873568927380942375986328765897983759837948563845689237593875275928579287589643589.exe
Made by: Kavru/KVR/kavrurl
Made in: C++
A Medium-Length GDI malware made within 2-3 days which it has 11-12 payloads
No credits.
Personally this is my favorite malware ever (in terms of effects)
Make sure to run as administrator btw
Works best in: Windows 7, 8, and 8.1
Supported on: Windows Vista-11 (Not 100% sure about Vista, but 7 and up for sure)