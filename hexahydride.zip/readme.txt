H      H EEEEEEE X    X     A     H      H Y   Y DDD   RRR   İ DDD   EEEEEEE   EEEEEEE X    X EEEEEEE
H      H E        X  X     A A    H      H  Y Y  D  D  R  R    D  D  E         E        X  X  E
HHHHHHHH EEEEEEE   XX     AAAAA   HHHHHHHH   Y   D   D RRR   İ D   D EEEEEEE   EEEEEEE   XX   EEEEEEE
H      H E        X  X   A     A  H      H   Y   D  D  R  R  İ D  D  E         E        X  X  E
H      H EEEEEEE X    X A       A H      H   Y   DDD   R   R İ DDD   EEEEEEE . EEEEEEE X    X EEEEEEE
Made by lipkoza
My new malware
This is my 5th piece of malware
Bye!