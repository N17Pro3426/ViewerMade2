                            █
                               █    █
                         █  █  █    █
████       ███           █  █  █    █
█  ███    ██ ███         █  █  █    █   ███
█   ██   ██    █      ████  █  ██   █   █  ████
█████    █     █      █  █  █   █  ██  █    █████
█   ██   ██   ██      █  █  █   ████   █    █   █
█    ██   ████████    ████  █               █   █
█      █         ██
█
█

Malware name: radium
Damage rate: Safe
Made in: C++
Made by: abraham106
Creation date: 13 July 2025

This is safe and it will show 7 GDI effects 
Skidded? A little bit...